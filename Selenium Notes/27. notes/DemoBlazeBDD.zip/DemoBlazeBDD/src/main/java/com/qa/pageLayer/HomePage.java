package com.qa.pageLayer;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class HomePage {
	
	WebDriver driver;
	public HomePage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	private By lnk_phones = By.xpath("//a[contains(text(),'Phones')]");
	private By lnk_samsung_galaxy_s6 = By.xpath("//a[contains(text(),'Samsung galaxy s6')]");
	private By lnk_nokia_lumia_1520 = By.xpath("//a[contains(text(),'Nokia lumia 1520')]");
	private By lnk_nexus6 = By.xpath("//a[contains(text(),'Nexus 6')]");
	private By btn_add_to_cart = By.xpath("//a[contains(text(),'Add to cart')]");
	
	public void clickOnPhones()
	{
		driver.findElement(lnk_phones).click();
	}
	
	public void ClickOnSamsungGalaxyS6()
	{
		driver.findElement(lnk_samsung_galaxy_s6).click();
	}
	
	public void ClickOnNokiaLumia1520()
	{
		driver.findElement(lnk_nokia_lumia_1520).click();
	}
	
	public void ClickOnNexus6()
	{
		driver.findElement(lnk_nexus6).click();
	}
	
	public void clickOnAddToCart()
	{
		driver.findElement(btn_add_to_cart).click();
	}
	
	public String getTextFromPopup()
	{
		return driver.switchTo().alert().getText();	 
	}
	
	public void clickOnOKButtonofPopup()
	{
		driver.switchTo().alert().accept();	 
	}
}
