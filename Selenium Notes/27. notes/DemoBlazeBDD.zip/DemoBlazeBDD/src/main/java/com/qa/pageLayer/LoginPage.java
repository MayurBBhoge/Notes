package com.qa.pageLayer;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class LoginPage {
	
	public LoginPage(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//a[@id='login2']")
	private WebElement login_btn1;
	
	public void clickOnLoginButton1()
	{
		login_btn1.click();
	}
	
	@FindBy(xpath="//input[@id='loginusername']")
	private WebElement username;
	
	public void enterUsername(String name)
	{
		username.sendKeys(name);;
	}
	
	@FindBy(xpath="//input[@id='loginpassword']")
	private WebElement password;
	
	public void enterPassword(String pass)
	{
		password.sendKeys(pass);;
	}
	
	
	@FindBy(xpath="//button[contains(text(),'Log in')]")
	private WebElement login_btn2;
	
	public void clickOnLoginButton2()
	{
		login_btn2.click();
	}

}
