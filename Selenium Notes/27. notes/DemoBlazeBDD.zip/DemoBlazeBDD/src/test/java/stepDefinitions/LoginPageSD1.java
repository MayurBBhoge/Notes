package stepDefinitions;

import com.driverfactory.DriverFactory;
import com.qa.pageLayer.LoginPage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginPageSD1 {
	private PageObjectManager pom = new PageObjectManager(DriverFactory.getDriver());	
	public LoginPage login;

	@Given("User is navigating to homepage")
	public void user_is_navigating_to_homepage() 
	{
	   login=pom.loginobj();
	}
	@When("Clicked on login button")
	public void clicked_on_login_button() 
	{
	   login.clickOnLoginButton1();
	}
	
	@When("User need to enter username as {string} , password as {string} and clicked on login")
	public void user_need_to_enter_username_as_password_as_and_clicked_on_login(String username, String password) {
		login.enterUsername(username);
	    login.enterPassword(password);
	    login.clickOnLoginButton2();
	}
	@Then("logged in sucessfully")
	public void logged_in_sucessfully() {
		System.out.println("User logged in sucessfully............."); 
	}
	
}
