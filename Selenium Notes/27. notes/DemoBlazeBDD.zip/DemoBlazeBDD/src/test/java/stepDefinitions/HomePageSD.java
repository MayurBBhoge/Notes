package stepDefinitions;

import org.testng.Assert;

import com.driverfactory.DriverFactory;
import com.qa.pageLayer.HomePage;

import io.cucumber.java.en.*;

public class HomePageSD {

	private PageObjectManager pom = new PageObjectManager(DriverFactory.getDriver());	
	private HomePage home;
	
	@Given("User is on homepage")
	public void user_is_on_homepage() {
		home = pom.homeobj();
	}
	@When("click on phone")
	public void click_on_phone() {
	    home.clickOnPhones();
	}

	//------------------------------------------------------
	@When("select \\(clicked on) Samsung galaxy s6 product link")
	public void select_clicked_on_samsung_galaxy_s6_product_link() {
	    home.ClickOnSamsungGalaxyS6();
	}
	
	@When("select \\(clicked on) Nexus6 product link")
	public void select_clicked_on_nexus6_product_link() {
		home.ClickOnNokiaLumia1520();
	}
	
	@When("select \\(clicked on) Nokia lumia1520 product link")
	public void select_clicked_on_nokia_lumia1520_product_link() {
	    home.ClickOnNexus6();
	}
	//--------------------------------------------------------------------
	@When("click on Add to cart button")
	public void click_on_add_to_cart_button() throws InterruptedException {
		Thread.sleep(2000);
		home.clickOnAddToCart();
	}
	@Then("shows {string} message on popup")
	public void shows_message_on_popup(String message) throws InterruptedException {
		Thread.sleep(2000);
		String actual_msg = home.getTextFromPopup();
	    System.out.println(actual_msg);
	    Assert.assertEquals(message, actual_msg);
	}
	@Then("click on OK button of popup")
	public void click_on_ok_button_of_popup() {
		   home.clickOnOKButtonofPopup();
	}

}
