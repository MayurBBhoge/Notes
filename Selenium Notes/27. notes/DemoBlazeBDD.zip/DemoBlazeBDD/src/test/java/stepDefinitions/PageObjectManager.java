package stepDefinitions;

import org.openqa.selenium.WebDriver;

import com.qa.pageLayer.HomePage;
import com.qa.pageLayer.LoginPage;

public class PageObjectManager {
	
	private WebDriver driver;
	private LoginPage login;
	private HomePage home;
	
	PageObjectManager(WebDriver driver)
	{
		this.driver=driver;
	}
	
	public HomePage homeobj()
	{
		home = new HomePage(driver);
		return home;
	}
	
	public LoginPage loginobj()
	{
		login = new LoginPage(driver);
		return login;
	}

}
