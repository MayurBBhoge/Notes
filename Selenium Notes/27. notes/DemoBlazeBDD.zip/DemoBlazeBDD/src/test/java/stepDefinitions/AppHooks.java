package stepDefinitions;

import org.openqa.selenium.WebDriver;
import com.driverfactory.DriverFactory;

import io.cucumber.java.After;
import io.cucumber.java.Before;

public class AppHooks {
	
	private DriverFactory driverfactory;
	private WebDriver driver;
	@Before 
	public void launchBrowser()
	{
		driverfactory = new DriverFactory();
		driver = driverfactory.init_browser("chrome");
	}

	@After 
	public void closeBrowser() throws InterruptedException
	{
		Thread.sleep(2000);
		driver.close();
	}
}
