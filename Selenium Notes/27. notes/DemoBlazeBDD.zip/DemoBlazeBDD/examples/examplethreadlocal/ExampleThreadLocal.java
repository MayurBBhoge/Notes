package examplethreadlocal;

public class ExampleThreadLocal {

	public static  ThreadLocal<String> tl = new ThreadLocal<String>();
	
	public String xyz(String city)
	{
		String city1= " is city";
		tl.set(city);
		System.out.println(getCity().length());
		return getCity();
	}
	
	public static synchronized String getCity() {
		return tl.get();
	}
	
	public static void main(String[] args) {
		ExampleThreadLocal obj = new ExampleThreadLocal();
		obj.xyz("fghjk");
		System.out.println(ExampleThreadLocal.getCity());
	}

}
