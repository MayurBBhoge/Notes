package managers;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class WebDriverManager {

	private WebDriver driver;
	
	private WebDriver createDriver()
	{
		String browser_name = "chrome";
		
		if(browser_name.equalsIgnoreCase("chrome"))
		{
			driver = new ChromeDriver();
		}
		else if(browser_name.equalsIgnoreCase("firefox"))
		{
			driver = new FirefoxDriver();
		}
		else if(browser_name.equalsIgnoreCase("edge"))
		{
			driver = new EdgeDriver();
		}
		else
		{
			System.out.println("Please provide proper browser name");
		}
		
		return driver;
	}
	
	public WebDriver getDriver()
	{
		if(driver==null)
		{
			driver = createDriver();
		}
		return driver;
	}
}
