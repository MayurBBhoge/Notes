package stepDefinations;

import java.util.List;

import org.testng.Assert;

import com.odoo.pageobjects.Homepage;
import com.odoo.pageobjects.Loginpage;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import managers.PageObjectManager;
import managers.TestContext;

public class Loginpage_step {

	private TestContext testcontext;
	private Loginpage loginpage_obj;
	private Homepage homepage_obj;
	
	public Loginpage_step(TestContext context)
	{
		testcontext = context;
//		pageobjectmanager = new PageObjectManager(testcontext.getWebDriverManager().getDriver());
//		pageobjectmanager = testcontext.getPageObjectManager();
		loginpage_obj = testcontext.getPageObjectManager().getLoginpage();
		homepage_obj = testcontext.getPageObjectManager().getHomepage();
		
	}
	
	@When("user enter login credentials:")
	public void user_enter_login_credentials(io.cucumber.datatable.DataTable dataTable) {
	   
		List<List<String>> data = dataTable.asLists();
		
		loginpage_obj.enterEmailAddress(data.get(1).get(0));
		loginpage_obj.enterPassword(data.get(1).get(1));		
		
	}
	
	@When("user click the Login button")
	public void user_click_the_login_button() {
		loginpage_obj.clickOnLoginButton();
	}
	
	@Then("user should see an error message as {string}")
	public void user_should_see_an_error_message_as(String expected_message) {
		String actual_message = loginpage_obj.getErrorMessage();
		System.out.println("This is actual error message :- " + actual_message);
		boolean status = actual_message.contains(expected_message);
		Assert.assertEquals(status, true);
	}
	
	@When("user is on the signup page")
	public void user_is_on_the_signup_page() {
	    homepage_obj.clickOnSignInLink();
	    loginpage_obj.clickOnDontHaveAccount();
	}
}
