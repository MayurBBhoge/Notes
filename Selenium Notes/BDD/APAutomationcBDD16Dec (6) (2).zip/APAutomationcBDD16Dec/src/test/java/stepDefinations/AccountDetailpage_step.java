package stepDefinations;

import java.util.List;

import com.odoo.pageobjects.AccountDetailspage;

import io.cucumber.java.en.When;
import managers.PageObjectManager;
import managers.TestContext;

public class AccountDetailpage_step {
	
	private TestContext testcontext;
	private AccountDetailspage accountdetailpage_obj;
	
	public AccountDetailpage_step(TestContext context)
	{
		testcontext = context;
//		pageobjectmanager = new PageObjectManager(testcontext.getWebDriverManager().getDriver());
//		pageobjectmanager = testcontext.getPageObjectManager();
		accountdetailpage_obj = testcontext.getPageObjectManager().getAccountDetailspage();
	}

	@When("user enter account details")
	public void user_enter_account_details(io.cucumber.datatable.DataTable dataTable) {
	   
		List<List<String>> data = dataTable.asLists();
		
		accountdetailpage_obj.fillAllAddressDetails(data.get(0).get(0), data.get(0).get(1), data.get(0).get(2), data.get(0).get(3), data.get(0).get(4), data.get(0).get(5), data.get(0).get(6), data.get(0).get(7), data.get(0).get(8));
		
	}
	@When("user clicks on save button")
	public void user_clicks_on_save_button() {
	    accountdetailpage_obj.clickOnSaveButton();
	}
}
