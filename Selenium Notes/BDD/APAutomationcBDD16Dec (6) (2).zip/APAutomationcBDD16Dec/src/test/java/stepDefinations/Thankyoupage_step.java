package stepDefinations;

import org.testng.Assert;

import com.odoo.pageobjects.Thankyoupage;

import io.cucumber.java.en.Then;
import managers.PageObjectManager;
import managers.TestContext;

public class Thankyoupage_step {
	
	private TestContext testcontext;
	private Thankyoupage thankyoupage_obj;
	
	public Thankyoupage_step(TestContext context)
	{
		testcontext = context;
		thankyoupage_obj = testcontext.getPageObjectManager().getThankyoupage();
	}

	@Then("user should be redirected to thank you page and shows {string}")
	public void user_should_be_redirected_to_thank_you_page_and_shows(String expected_result) {
	 
		String actual_result = thankyoupage_obj.getThankYouMessage();
		System.out.println("The actual message is :- "+actual_result);
		Assert.assertEquals(actual_result, expected_result);
	}
}
