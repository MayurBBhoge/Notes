package stepDefinations;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.io.FileHandler;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import managers.TestContext;

public class AppHooks {

	private TestContext testcontext;
	
	public AppHooks(TestContext context)
	{
		testcontext = context;
	}
	
	@Before
	public void setUp()
	{
		WebDriver driver = testcontext.getWebDriverManager().getDriver();
		driver.get("https://ap-automation.odoo.com/");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	}
	
	@After
	public void tearDown(Scenario scenario)
	{
		if(scenario.isFailed())
		{
			TakesScreenshot ts = (TakesScreenshot)testcontext.getWebDriverManager().getDriver();
			 final byte[] src = ts.getScreenshotAs(OutputType.BYTES);
			 scenario.attach(src, "png", scenario.getName());
		}
		testcontext.getWebDriverManager().getDriver().quit();
//		driver.quit();
	}
	
	/*
	 * try 
			{
				String path = ".\\screenshots\\";		
				TakesScreenshot ts = (TakesScreenshot)testcontext.getWebDriverManager().getDriver();
				File src = ts.getScreenshotAs(OutputType.FILE);
				
				File des = new File(path + scenario.getName() +".png");	
				FileHandler.copy(src, des);
			} 
			catch (IOException e) 
			{
				e.printStackTrace();
			}
	 */
}
