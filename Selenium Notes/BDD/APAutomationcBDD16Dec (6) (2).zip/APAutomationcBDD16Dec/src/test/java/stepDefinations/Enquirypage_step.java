package stepDefinations;

import com.odoo.pageobjects.Enquirypage;

import io.cucumber.java.en.When;
import managers.PageObjectManager;
import managers.TestContext;

public class Enquirypage_step {
	
	private TestContext testcontext;
	private Enquirypage enquirypage_obj;

	public Enquirypage_step(TestContext context)
	{
		testcontext = context;
		enquirypage_obj = testcontext.getPageObjectManager().getEnquirypage();
	}

	@When("enter details as {string} {string} {string} {string} {string} {string}")
	public void enter_details_as(String name, String number, String email, String company, String subject, String question) {
	    
		enquirypage_obj.enterFormDetails(name, number, email, company, subject, question);
	}
	@When("user clicks on submit button")
	public void user_clicks_on_submit_button() throws InterruptedException {
		enquirypage_obj.clickOnSubmitButton();
		Thread.sleep(5000);
	}
}
