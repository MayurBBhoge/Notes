package managers;

import org.openqa.selenium.WebDriver;

import com.odoo.pageobjects.AccountDetailspage;
import com.odoo.pageobjects.Enquirypage;
import com.odoo.pageobjects.Homepage;
import com.odoo.pageobjects.Loginpage;
import com.odoo.pageobjects.MyAccountpage;
import com.odoo.pageobjects.Signuppage;
import com.odoo.pageobjects.Thankyoupage;

public class PageObjectManager {

	private WebDriver driver;
	
	Homepage homepage_obj; 
	Loginpage loginpage_obj;
	MyAccountpage accountpage_obj;
	Signuppage signuppage_obj;
	Enquirypage enquirypage_obj;
	Thankyoupage thankyoupage_obj;
	AccountDetailspage accountdetailpage_obj;
	
	public PageObjectManager(WebDriver driver)
	{
		this.driver = driver;
	}
	
	public Homepage getHomepage()
	{
		homepage_obj = new Homepage(driver);
		return homepage_obj;
	}
	
	public Loginpage getLoginpage()
	{
		loginpage_obj = new Loginpage(driver);
		return loginpage_obj;
	}
	
	public Signuppage getSignuppage()
	{
		signuppage_obj = new Signuppage(driver);
		return signuppage_obj;
	}
	
	public MyAccountpage getMyAccountpage()
	{
		accountpage_obj = new MyAccountpage(driver);
		return accountpage_obj;
	}
	
	public Enquirypage getEnquirypage()
	{
		enquirypage_obj = new Enquirypage(driver);
		return enquirypage_obj;
	}
	
	public Thankyoupage getThankyoupage()
	{
		thankyoupage_obj = new Thankyoupage(driver);
		return thankyoupage_obj;
	}
	
	public AccountDetailspage getAccountDetailspage()
	{
		accountdetailpage_obj = new AccountDetailspage(driver);
		return accountdetailpage_obj;
	}
}
