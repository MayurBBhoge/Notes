package stepDefinations;

import org.testng.Assert;

import com.odoo.pageobjects.MyAccountpage;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import managers.PageObjectManager;

public class MyAccountpage_step {
	
	PageObjectManager pageobjectmanager;
	MyAccountpage accountpage_obj;
	
	MyAccountpage_step()
	{
		pageobjectmanager = new PageObjectManager(driver);
		pageobjectmanager.getMyAccountpage();
	}

	@Then("user should be redirected to the my account page and verify username as {string}")
	public void user_should_be_redirected_to_the_my_account_page_and_verify_username_as(String expected_result) {
	    
		String actual_result = accountpage_obj.getUsername();
		System.out.println("Account user name is :- " + actual_result);
		Assert.assertEquals(actual_result, expected_result);
	}
	
	@When("user clicks on address link")
	public void user_clicks_on_address_link() {
	    accountpage_obj.clickOnAddressLink();
	}
}
