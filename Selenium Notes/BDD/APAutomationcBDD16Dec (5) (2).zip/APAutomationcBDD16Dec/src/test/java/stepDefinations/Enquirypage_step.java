package stepDefinations;

import com.odoo.pageobjects.Enquirypage;

import io.cucumber.java.en.When;
import managers.PageObjectManager;

public class Enquirypage_step {
	
	PageObjectManager pageobjectmanager;
	Enquirypage enquirypage_obj;

	Enquirypage_step()
	{
		pageobjectmanager = new PageObjectManager(driver);
		enquirypage_obj = pageobjectmanager.getEnquirypage();
	}

	@When("enter details as {string} {string} {string} {string} {string} {string}")
	public void enter_details_as(String name, String number, String email, String company, String subject, String question) {
	    
		enquirypage_obj.enterFormDetails(name, number, email, company, subject, question);
	}
	@When("user clicks on submit button")
	public void user_clicks_on_submit_button() throws InterruptedException {
		enquirypage_obj.clickOnSubmitButton();
		Thread.sleep(5000);
	}
}
