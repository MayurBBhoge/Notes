package stepDefinations;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.odoo.pageobjects.AccountDetailspage;
import com.odoo.pageobjects.Enquirypage;
import com.odoo.pageobjects.Homepage;
import com.odoo.pageobjects.Loginpage;
import com.odoo.pageobjects.MyAccountpage;
import com.odoo.pageobjects.Signuppage;
import com.odoo.pageobjects.Thankyoupage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import managers.PageObjectManager;
import managers.TestContext;

public class Homepage_step {
	
	private TestContext testcontext;
	Homepage homepage_obj; 
	
	public Homepage_step(TestContext context)
	{
		testcontext = context;
		homepage_obj = testcontext.getPageObjectManager().getHomepage();
	}
	
	@Given("user is on the home page")
	public void user_is_on_the_home_page() {
	   
	}
	
	@When("user clicks on signin link")
	public void user_clicks_on_signin_link() {
		homepage_obj.clickOnSignInLink();
	}
	
	@When("user clicks on enquiry form link")
	public void user_clicks_on_enquiry_form_link() {
	    homepage_obj.clickOnEnquiryFormLink();
	}
}
