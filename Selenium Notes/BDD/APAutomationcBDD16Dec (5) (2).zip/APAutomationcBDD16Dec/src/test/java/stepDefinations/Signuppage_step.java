package stepDefinations;

import java.util.List;

import com.odoo.pageobjects.Signuppage;

import io.cucumber.java.en.When;
import managers.PageObjectManager;

public class Signuppage_step {
	
	PageObjectManager pageobjectmanager;
	Signuppage signuppage_obj;

	Signuppage_step()
	{
		pageobjectmanager = new PageObjectManager(driver);
		signuppage_obj = pageobjectmanager.getSignuppage();	
	}

	@When("user enter information:")
	public void user_enter_information(io.cucumber.datatable.DataTable dataTable) {
		List<List<String>> data = dataTable.asLists();
		
		signuppage_obj.enterEmailAddress(data.get(1).get(0));
		signuppage_obj.enterUsername(data.get(1).get(1));
		signuppage_obj.enterPassword(data.get(1).get(2));
		signuppage_obj.enterConfirmPassword(data.get(1).get(3));
		
	}
	@When("user click the Sign Up button")
	public void user_click_the_sign_up_button() {
		signuppage_obj.clickOnSignupButton();
	}
}
