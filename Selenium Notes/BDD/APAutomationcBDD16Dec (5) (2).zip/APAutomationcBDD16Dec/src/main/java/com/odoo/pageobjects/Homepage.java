package com.odoo.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Homepage {
	
	private WebDriver driver;
	public Homepage(WebDriver driver)
	{
		this.driver = driver;
	}
	
	//------------ Obj repo ------------
	
	private By signin_link = By.xpath("(//a[text()='Sign in'])[1]");
	private By enquiry_form_link = By.xpath("(//span[text()='Enquiry Form'])[1]");
	
	//------------ Action Methods ------
	public void clickOnSignInLink()
	{
		driver.findElement(signin_link).click();
	}
	
	public void clickOnEnquiryFormLink()
	{
		driver.findElement(enquiry_form_link).click();
	}

}
