package com.odoo.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Enquirypage {
	
	private WebDriver driver;
	public Enquirypage(WebDriver driver)
	{
		this.driver = driver;
	}
	
	//------------ Obj repo ------------
	
	private By name_textbox = By.xpath("//input[@id='obij2aulqyau']");
	private By number_textbox = By.xpath("//input[@id='ozp7022vqhe']");
	private By email_textbox = By.xpath("//input[@id='oub62hlfgjwf']");
	private By company_textbox = By.xpath("//input[@id='o291di1too2s']");
	private By subject_textbox = By.xpath("//input[@id='oqsf4m51acj']");
	private By question_textbox = By.xpath("//textarea[@id='oyeqnysxh10b']");
	private By submit_btn = By.xpath("//a[contains(text(),'Submit')]");
	
	//------------ Action Methods ------
	public void enterFormDetails(String name, String number, String email, String company, String subject, String question)
	{
		driver.findElement(name_textbox).sendKeys(name);
		driver.findElement(number_textbox).sendKeys(number);
		driver.findElement(email_textbox).sendKeys(email);
		driver.findElement(company_textbox).sendKeys(company);
		driver.findElement(subject_textbox).sendKeys(subject);
		driver.findElement(question_textbox).sendKeys(question);
	}
	
	public void clickOnSubmitButton()
	{
		driver.findElement(submit_btn).click();
	}
}
