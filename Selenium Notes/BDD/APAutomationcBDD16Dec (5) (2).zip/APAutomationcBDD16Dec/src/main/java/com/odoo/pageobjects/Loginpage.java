package com.odoo.pageobjects;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Loginpage {


	private WebDriver driver;
	public Loginpage(WebDriver driver)
	{
		this.driver = driver;
	}
	
	//------------ Obj repo ------------
	
	private By email_textbox = By.xpath("//input[@id='login']");
	private By password_textbox = By.xpath("//input[@id='password']");
	private By login_btn = By.xpath("//button[contains(text(),'Log in')]");
	
	private By donthaveaccount_link = By.xpath("//a[contains(text(),\"Don't have an account?\")]");
	private By error_message = By.xpath("//p[@class='alert alert-danger']");
	
	//------------ Action Methods ------
	
	public void enterEmailAddress(String email)
	{
		driver.findElement(email_textbox).sendKeys(email);
	}
	
	public void enterPassword(String password)
	{
		driver.findElement(password_textbox).sendKeys(password);
	}
	
	public void clickOnLoginButton()
	{
		driver.findElement(login_btn).click();;
	}
	
	public void clickOnDontHaveAccount()
	{
		driver.findElement(donthaveaccount_link).click();
	}
	
	public String getErrorMessage()
	{
		return driver.findElement(error_message).getText();
	}
	
	private WebElement waitElementToDisplay(By element_xpath)
	{
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(element_xpath));
		return element;
	}
}
