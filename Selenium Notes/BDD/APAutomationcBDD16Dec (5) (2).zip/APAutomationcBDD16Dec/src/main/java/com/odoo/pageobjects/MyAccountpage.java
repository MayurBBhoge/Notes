package com.odoo.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class MyAccountpage {

	private WebDriver driver;
	public MyAccountpage(WebDriver driver)
	{
		this.driver = driver;
	}
	
	//obj 
	private By get_username = By.xpath("//h5[@class='mb-0']");
	private By address_link = By.xpath("//a[@title='Addresses']");
	
	public String getUsername()
	{
		WebElement username = driver.findElement(get_username);
		String text = "";
		if(username.isDisplayed())
		{
			text = username.getText();
		}	
		return text;
	}
	
	public void clickOnAddressLink()
	{
		driver.findElement(address_link).click();
	}
}
