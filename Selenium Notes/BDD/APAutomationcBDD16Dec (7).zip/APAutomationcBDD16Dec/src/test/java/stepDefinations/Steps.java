package stepDefinations;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import com.odoo.pageobjects.Homepage;
import com.odoo.pageobjects.Loginpage;
import com.odoo.pageobjects.MyAccountpage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Steps {

	
	private WebDriver driver;
	Homepage homepage_obj; 
	Loginpage loginpage_obj;
	MyAccountpage accountpage_obj;
	
	@Given("user is on the home page")
	public void user_is_on_the_home_page() {
	    driver = new ChromeDriver();
	    driver.get("https://ap-automation.odoo.com/");
	    driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	    
	    // -------------------------------
	    homepage_obj = new Homepage(driver);
	    loginpage_obj = new Loginpage(driver);
	    accountpage_obj = new MyAccountpage(driver);
	    
	    
	}
	@When("user clicks on signin link")
	public void user_clicks_on_signin_link() {
		homepage_obj.clickOnSignInLink();
	}
	@When("user enter login credentials:")
	public void user_enter_login_credentials(io.cucumber.datatable.DataTable dataTable) {
	   
		List<List<String>> data = dataTable.asLists();
		
		loginpage_obj.enterEmailAddress(data.get(1).get(0));
		loginpage_obj.enterPassword(data.get(1).get(1));		
		
	}
	@When("user click the Login button")
	public void user_click_the_login_button() {
		loginpage_obj.clickOnLoginButton();
	}
	@Then("user should be redirected to the my account page and verify username as {string}")
	public void user_should_be_redirected_to_the_my_account_page_and_verify_username_as(String expected_result) {
	    
		String actual_result = accountpage_obj.getUsername();
		System.out.println("Account user name is :- " + actual_result);
		Assert.assertEquals(actual_result, expected_result);
	}
}
