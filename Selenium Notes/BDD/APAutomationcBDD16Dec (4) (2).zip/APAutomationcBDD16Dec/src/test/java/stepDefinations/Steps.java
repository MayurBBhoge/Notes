package stepDefinations;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import com.odoo.pageobjects.AccountDetailspage;
import com.odoo.pageobjects.Enquirypage;
import com.odoo.pageobjects.Homepage;
import com.odoo.pageobjects.Loginpage;
import com.odoo.pageobjects.MyAccountpage;
import com.odoo.pageobjects.Signuppage;
import com.odoo.pageobjects.Thankyoupage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import managers.PageObjectManager;

public class Steps {

	
	private WebDriver driver;
	Homepage homepage_obj; 
	Loginpage loginpage_obj;
	MyAccountpage accountpage_obj;
	Signuppage signuppage_obj;
	Enquirypage enquirypage_obj;
	Thankyoupage thankyoupage_obj;
	AccountDetailspage accountdetailpage_obj;
	
	@Given("user is on the home page")
	public void user_is_on_the_home_page() {
	    driver = new ChromeDriver();
	    driver.get("https://ap-automation.odoo.com/");
	    driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	    
	    // -------------------------------
	    
	    PageObjectManager pageobjectmanager = new PageObjectManager(driver);
	    homepage_obj = pageobjectmanager.getHomepage();
	    loginpage_obj = pageobjectmanager.getLoginpage();
	    accountpage_obj = pageobjectmanager.getMyAccountpage();
	    signuppage_obj = pageobjectmanager.getSignuppage();
	    enquirypage_obj = pageobjectmanager.getEnquirypage();
	    thankyoupage_obj = pageobjectmanager.getThankyoupage();
	    accountdetailpage_obj = pageobjectmanager.getAccountDetailspage();
	    
//	    homepage_obj = new Homepage(driver);
//	    loginpage_obj = new Loginpage(driver);
//	    accountpage_obj = new MyAccountpage(driver);
//	    signuppage_obj = new Signuppage(driver);
//	    enquirypage_obj = new Enquirypage(driver);
//	    thankyoupage_obj = new Thankyoupage(driver);
//	    accountdetailpage_obj = new AccountDetailspage(driver);
	    
	}
	@When("user clicks on signin link")
	public void user_clicks_on_signin_link() {
		homepage_obj.clickOnSignInLink();
	}
	@When("user enter login credentials:")
	public void user_enter_login_credentials(io.cucumber.datatable.DataTable dataTable) {
	   
		List<List<String>> data = dataTable.asLists();
		
		loginpage_obj.enterEmailAddress(data.get(1).get(0));
		loginpage_obj.enterPassword(data.get(1).get(1));		
		
	}
	@When("user click the Login button")
	public void user_click_the_login_button() {
		loginpage_obj.clickOnLoginButton();
	}
	@Then("user should be redirected to the my account page and verify username as {string}")
	public void user_should_be_redirected_to_the_my_account_page_and_verify_username_as(String expected_result) {
	    
		String actual_result = accountpage_obj.getUsername();
		System.out.println("Account user name is :- " + actual_result);
		Assert.assertEquals(actual_result, expected_result);
	}
	
	@Then("user should see an error message as {string}")
	public void user_should_see_an_error_message_as(String expected_message) {
		String actual_message = loginpage_obj.getErrorMessage();
		System.out.println("This is actual error message :- " + actual_message);
		boolean status = actual_message.contains(expected_message);
		Assert.assertEquals(status, true);
	}
	
	//------------------------------
	@When("user is on the signup page")
	public void user_is_on_the_signup_page() {
	    homepage_obj.clickOnSignInLink();
	    loginpage_obj.clickOnDontHaveAccount();
	}
	@When("user enter information:")
	public void user_enter_information(io.cucumber.datatable.DataTable dataTable) {
		List<List<String>> data = dataTable.asLists();
		
		signuppage_obj.enterEmailAddress(data.get(1).get(0));
		signuppage_obj.enterUsername(data.get(1).get(1));
		signuppage_obj.enterPassword(data.get(1).get(2));
		signuppage_obj.enterConfirmPassword(data.get(1).get(3));
		
	}
	@When("user click the Sign Up button")
	public void user_click_the_sign_up_button() {
		signuppage_obj.clickOnSignupButton();
	}
	
	//------------
	@When("user clicks on enquiry form link")
	public void user_clicks_on_enquiry_form_link() {
	    homepage_obj.clickOnEnquiryFormLink();
	}
	@When("enter details as {string} {string} {string} {string} {string} {string}")
	public void enter_details_as(String name, String number, String email, String company, String subject, String question) {
	    
		enquirypage_obj.enterFormDetails(name, number, email, company, subject, question);
	}
	@When("user clicks on submit button")
	public void user_clicks_on_submit_button() throws InterruptedException {
		enquirypage_obj.clickOnSubmitButton();
		Thread.sleep(5000);
	}
	@Then("user should be redirected to thank you page and shows {string}")
	public void user_should_be_redirected_to_thank_you_page_and_shows(String expected_result) {
	 
		String actual_result = thankyoupage_obj.getThankYouMessage();
		System.out.println("The actual message is :- "+actual_result);
		Assert.assertEquals(actual_result, expected_result);
	}
	

	@When("user clicks on address link")
	public void user_clicks_on_address_link() {
	    accountpage_obj.clickOnAddressLink();
	}
	@When("user enter account details")
	public void user_enter_account_details(io.cucumber.datatable.DataTable dataTable) {
	   
		List<List<String>> data = dataTable.asLists();
		
		accountdetailpage_obj.fillAllAddressDetails(data.get(0).get(0), data.get(0).get(1), data.get(0).get(2), data.get(0).get(3), data.get(0).get(4), data.get(0).get(5), data.get(0).get(6), data.get(0).get(7), data.get(0).get(8));
		
	}
	@When("user clicks on save button")
	public void user_clicks_on_save_button() {
	    accountdetailpage_obj.clickOnSaveButton();
	}
}
