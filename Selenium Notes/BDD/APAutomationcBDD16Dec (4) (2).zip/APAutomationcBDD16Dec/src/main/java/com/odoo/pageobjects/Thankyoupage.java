package com.odoo.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Thankyoupage {

	private WebDriver driver;
	public Thankyoupage(WebDriver driver)
	{
		this.driver = driver;
	}
	
	//----- obj ------------------
	
	
	//--------- action methods -----------
	public String getThankYouMessage()
	{
		String text = driver.findElement(By.xpath("//h1[contains(text(),'Thank You!')]")).getText();
		return text;
	}
	
}
