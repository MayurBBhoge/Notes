describe('First Script for WDIO', () => {

    xit('Locators Techniques - 5', async () => {

        await browser.url('https://stqatools.com/demo/Register.php');
        await browser.maximizeWindow();
        await browser.pause(3000);

        var name_txtbox = await $("//input[contains(@placeholder,'your name')]");
        await name_txtbox.setValue("David Miller");
        await browser.pause(3000);
    })

    it('Element Operations -1 ', async () => {

        await browser.url('https://www.facebook.com/');
        await browser.maximizeWindow();
        await browser.pause(3000);

        var element = await $("//h2[@class='_8eso']");
        var text =  await element.getText();
        console.log(text);
        await browser.pause(3000);

       var email_txtbox = await $("//input[@id='email']");
       await email_txtbox.setValue("David");
       await browser.pause(3000);
       await email_txtbox.addValue("123@gmail.com");
       await browser.pause(3000);

       var login_btn = await $("//button[contains(text(),'Log in')]")
       var status = await login_btn.isDisplayed();
       console.log(status)

       if(status)
        {
            login_btn.click();
        }
    })
} )