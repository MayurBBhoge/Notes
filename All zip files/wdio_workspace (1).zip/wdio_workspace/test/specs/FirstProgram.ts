describe('First Script for WDIO', () => {

    xit('Get browser methods', async () => {

        await browser.url('https://www.saucedemo.com/');
        var title = await browser.getTitle();
        console.log("Title of the page is :- " + title);
        console.log('Current url of the page is :- '+ await browser.getUrl());
        console.log('Page Source of the page is :- '+ await browser.getPageSource());
        await browser.pause(10000);
    })

    xit('navigate commands', async () => {

        await browser.url('https://www.saucedemo.com/');
        await browser.pause(3000);
        await browser.navigateTo('https://webdriver.io/');
        await browser.pause(3000);
        await browser.back();
        await browser.pause(3000);
        await browser.forward();
        await browser.pause(3000);
        await browser.refresh();
        await browser.pause(10000);
    })

    xit('browsers commands', async () => {

        await browser.url('https://www.saucedemo.com/');
        await browser.pause(3000);
        await browser.maximizeWindow();
        await browser.pause(3000);
        await browser.minimizeWindow();
        await browser.pause(3000);
        await browser.fullscreenWindow();
        await browser.pause(3000);

    })

    xit('Window size and Position', async () => {

        await browser.url('https://www.saucedemo.com/');
        await browser.pause(3000);
        console.log(await browser.getWindowSize());
        await browser.pause(3000);
        await browser.setWindowSize(1000,500);
        await browser.pause(3000);
        console.log(await browser.getWindowRect());
        await browser.setWindowRect(1000,500,500,500);
        await browser.pause(10000);

    })

} )