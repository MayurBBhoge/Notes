describe('First Script for WDIO', () => {

    xit('Locators Techniques - 1', async () => {

        await browser.url('https://www.saucedemo.com/');
        await browser.maximizeWindow();
        await browser.pause(3000);

        var username_txtbox = await $('#user-name');
        await username_txtbox.setValue("standard_user");
        await browser.pause(3000);

        var password_txtbox = await $('#password');
        await password_txtbox.setValue("secret_sauce");
        await browser.pause(3000);

        var login_btn = await $('[name="login-button"]');
        await login_btn.click();
        await browser.pause(3000);
    })

    xit('Locators Techniques - 2', async () => {

        await browser.url('https://www.facebook.com/');
        await browser.maximizeWindow();
        await browser.pause(3000);

        // var fp_link = await $('=Forgotten password?');
        var fp_link = await $('*=otten pas');
        await fp_link.click();
        await browser.pause(3000);
    })

    xit('Locators Techniques - 3', async () => {

        await browser.url('https://www.saucedemo.com/');
        await browser.maximizeWindow();
        await browser.pause(3000);

        // var h4_element = await $('h4=Accepted usernames are:');
        var h4_element = await $('h4*=Accepted user');
        var text = await h4_element.getText();
        console.log(text);
    })
} )