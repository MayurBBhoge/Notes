describe('Script for WDIO', () => {

    it('Dropdown handling', async () => {

        await browser.url('https://stqatools.com/demo/Register.php');
        await browser.maximizeWindow();
        await browser.pause(3000);

        var country_dropdown = await $("//select[@id='country']");
        // await country_dropdown.selectByIndex(5);
        // await country_dropdown.selectByVisibleText("Canada");
        await country_dropdown.selectByAttribute("value","UK");
        await browser.pause(5000);

        // var status = await country_dropdown.isSelected();
        // console.log(status);

    })
})