describe('Script for WDIO', () => {

    xit('Elemet op  - 2', async () => {

        await browser.url('C:/Users/232338/OneDrive/Desktop/16Dec/New%20folder/Index.html');
        await browser.maximizeWindow();
        await browser.pause(3000);

        var link = await $("//a[@id='dshhsd']");
        var status = await link.isEnabled();
        console.log(status);
        
    })

    it('Element op - 3', async () => {

        await browser.url('https://stqatools.com/demo/Register.php');
        await browser.maximizeWindow();
        await browser.pause(3000);

        var male_radio = await $("//input[@id='male']");
        var status = await male_radio.isSelected();
        console.log(status);

        if(!status)
        {
            await male_radio.click();
        }

        var male_radio1 = await $("//input[@id='mal']");
        var status1 = await male_radio1.isExisting();
        console.log(status1);

        var name_txtbox = await $("//input[contains(@placeholder,'your name')]");
        await name_txtbox.setValue("David Miller");
        await browser.pause(3000);

        var text = await name_txtbox.getValue();
        console.log(text);

        var co_ordinates = await name_txtbox.getLocation();
        console.log(co_ordinates)
        
        var elment = await $("(//a[@class='nav-link'])[3]");
        var value = await elment.getAttribute("href");
        console.log(value)
    })
})