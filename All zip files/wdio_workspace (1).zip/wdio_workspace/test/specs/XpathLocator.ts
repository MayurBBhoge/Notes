describe('First Script for WDIO', () => {

    it('Xpath Locator -1 ', async () => {

        await browser.url('https://www.facebook.com/');
        await browser.maximizeWindow();
        await browser.pause(3000);

        var email_textbox = await $("//input[@id='email']");
        email_textbox.setValue("david@gmail.com");
        await browser.pause(3000);

        var password_textbox = await $("//input[@class='inputtext _55r1 _6luy _9npi']");
        password_textbox.setValue("hdgsugfuwhe");
        await browser.pause(3000);

        var login_btn = await $('//button[text()="Log in"]');
        await login_btn.click();
        await browser.pause(3000);
    })

   

} )