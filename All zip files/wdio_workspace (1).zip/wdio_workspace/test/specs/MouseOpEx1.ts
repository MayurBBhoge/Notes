describe('First Script for WDIO', () => {

    xit('Mouse Opeartion - 1', async () => {

        await browser.url('https://stqatools.com/demo/DoubleClick.php');
        await browser.maximizeWindow();
        await browser.pause(3000);

        // var interaction_link = await $("//a[contains(text(),'Interactions')]");
        // await interaction_link.click;
        // await browser.pause(3000);

        // var d_link = await $("//a[contains(text(),'Double Click')]");
        // await d_link.click;
        // await browser.pause(3000);

        var element = await $("//button[text()='Click Me / Double Click Me!']");
        await element.doubleClick();
        await browser.pause(3000);
    })

    xit('Mouse Opeartion - 2', async () => {

        await browser.url('https://www.browserstack.com/');
        await browser.maximizeWindow();
        await browser.pause(3000);

        var developer_link = await $("//button[text()='Developers']");
        developer_link.moveTo();
        await browser.pause(3000);

        var doc_link = await $("//span[text()='Documentation']");
        await doc_link.click();
        await browser.pause(3000);

    })

    it('Mouse Opeartion - 3', async () => {

        await browser.url('https://jqueryui.com/droppable/');
        await browser.maximizeWindow();
        await browser.pause(3000);

        var iframe_1 = await $("//iframe[@class='demo-frame']");
        browser.switchToFrame(iframe_1);

        var src = await $("//div[@id='draggable']");      
        var des = await $("//div[@id='droppable']");
        await browser.pause(3000);

        src.dragAndDrop(des);
        await browser.pause(3000);

    })
        
})