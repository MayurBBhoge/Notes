describe('First Script for WDIO', () => {

    xit('Alert Popup Opeartion - 1', async () => {

        await browser.url('https://stqatools.com/demo/Alerts.php');
        await browser.maximizeWindow();
        await browser.pause(3000);

        var basic_alert_btn = await $("//button[@id='jbalert']");
        await basic_alert_btn.click();
        await browser.pause(3000);
        browser.acceptAlert();
        await browser.pause(3000);

        var confirm_alert_btn = await $("//button[@id='jcalert']");
        await confirm_alert_btn.click();
        await browser.pause(3000);
        var text1 = await browser.getAlertText();
        console.log(text1);
        browser.dismissAlert();
        await browser.pause(3000);

        var prompt_alert_btn = await $("//button[@id='jpalert']");
        await prompt_alert_btn.click();
        await browser.pause(3000);
        await browser.sendAlertText("Hello World");
        await browser.pause(3000);
        browser.acceptAlert();
        await browser.pause(3000);
    })

    xit('Window Popup Opeartion - 1', async () => {

        await browser.url('https://stqatools.com/demo/Windows.php');
        await browser.maximizeWindow();
        await browser.pause(3000);

        var element1 = await $("(//button[@class='btn btn-info'])[1]");
        await element1.click();
        await browser.pause(3000);
        var title = await browser.getTitle();
        console.log(title);
        await browser.pause(3000);

        var p_id = await browser.getWindowHandle();
        console.log("Parent ID :- " + p_id);

        var c_ids = await browser.getWindowHandles();
        console.log("Child IDs :- " + c_ids);
        await browser.pause(3000);

        await browser.switchToWindow(c_ids[1]);
        var title = await browser.getTitle();
        console.log(title);

        var element2 = await $("(//span[text()='Selenium'])[1]");
        await element2.click();
        await browser.pause(3000);
    })

   
})