describe('First Script for WDIO', () => {

    it('iFrame Handling - 1', async () => {

        await browser.url('https://chercher.tech/practice/frames');
        await browser.maximizeWindow();
        await browser.pause(3000);

        var ele1 = await $("//label[1]");
        var text = await ele1.getText();
        console.log(text);

        await browser.switchToFrame(0);
        var ele2 = await $("//input[@type='text']");
        await ele2.setValue("English");
        await browser.pause(3000);

        // await browser.switchToParentFrame();
        await browser.switchToFrame(null);
        await browser.pause(3000);

        var f1 = await $("//iframe[@id='frame2']");
        await browser.switchToFrame(f1);

        var ele3 = await $("//select[@id='animals']");
        await ele3.selectByVisibleText("Avatar");
        await browser.pause(3000);
    })
})