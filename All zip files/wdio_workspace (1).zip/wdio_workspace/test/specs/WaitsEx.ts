describe('First Script for WDIO', () => {

    xit('Alert Popup Opeartion - 1', async () => {

        await browser.url('https://webdriveruniversity.com/Ajax-Loader/index.html');
        await browser.maximizeWindow();
       

        var element1 = await $("//p[text()='CLICK ME!']");
        await element1.waitForClickable({timeout: 5000, timeoutMsg: "Element is not clickable"});
        await element1.click();
    })  


    xit('Waits Op - 1', async () => {

        await browser.url('https://the-internet.herokuapp.com/dynamic_loading/1');
        await browser.maximizeWindow();
       

        var element1 = await $("//button[text()='Start']");
        await element1.click();

        var element2 = await $("//h4[text()='Hello World!']");
        await element2.waitForDisplayed();
        var text = await element2.getText();
        console.log(text);
    })  

    it('Waits Op - 2', async () => {

        await browser.url('https://the-internet.herokuapp.com/dynamic_controls');
        await browser.maximizeWindow();
       
        var element1 = await $("//input[@type='text']");
        var s = await element1.isEnabled();
        console.log(s);

        var element2 = await $("(//button[@type='button'])[2]");
        await element2.click();
        await element1.waitForEnabled();
        var s = await element1.isEnabled();
        console.log(s);
      
    })  
})