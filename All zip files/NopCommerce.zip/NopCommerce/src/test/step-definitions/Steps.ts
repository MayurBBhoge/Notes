import { Given, When } from "@wdio/cucumber-framework"; 

Given('user is on the home page', async () => {
    await browser.url('https://demo.nopcommerce.com/');
    await browser.maximizeWindow();
})

When('user clicks on register link', async () => {
    var register_link = await $("//a[text()='Register']");
    register_link.click();
})

When('user enters firstname {string} and lastname {string} and email {string} and comname {string} and password {string} and confirm password {string}', async (firstname, lastname, email, comName, password, confirmpassword) => {
    
    (await $("//input[@id='FirstName']")).setValue(firstname);
    (await $("//input[@id='LastName']")).setValue(lastname);
    (await $("//input[@id='Email']")).setValue(email);
    (await $("//input[@id='Company']")).setValue(comName);
    (await $("//input[@id='Password']")).setValue(password);
    (await $("//input[@id='ConfirmPassword']")).setValue(confirmpassword);

})

When('user selects gender as {string} and DOB as {string} {string} {string}', async (gender, date, month, year) => {
   console.log(gender);
    (await $("//input[@id='gender-male']")).click;
   (await $("//select[@name='DateOfBirthDay']")).selectByVisibleText(date);
   (await $("//select[@name='DateOfBirthMonth']")).selectByVisibleText(month);
   (await $("//select[@name='DateOfBirthYear']")).selectByVisibleText(year);
})

When('user clicks on register button', async () => {
    (await $("//button[@id='register-button']")).click;
    await browser.pause(5000);
})

// Then('', async () => {

// })