// import {Given, When, Then} from "@wdio/cucumber-framework"

// Given('user is on the home page', async () => {
//     console.log("1");
// })

// When('user clicks on login link', async () => {
//     console.log("2");
// })

// When('user enter login details:', async () => {
//     console.log("3");
// })

// When("user click the Login button", async () => {
//     console.log("4");
// })

// Then("user should be redirected to the my account page and verify username as {string}", async () => {
//     console.log("5");
// })